# This is an example of training a 5-layers network with 50 units in each hidden layer.
# You need to adjust the following things:
#   - the number of layers
#   - the number of hidden units
#   - learning rate
#   - lambda_reg
#   - weight scale
#   - batch_size
#   - num_epoch
#   - ......
#  Revise this example for training your model.
from __future__ import print_function
import numpy as np
import matplotlib.pyplot as plt

from data_utils import get_CIFAR10_data
from fcnet import FullyConnectedNet
from solver import Solver

# get_ipython().magic(u'matplotlib inline')
plt.rcParams['figure.figsize'] = (10.0, 8.0)
plt.rcParams['image.interpolation'] = 'nearest'
plt.rcParams['image.cmap'] = 'gray'

# load data
data = get_CIFAR10_data()

# set up parameters for a model
h1, h2, h3, h4 = 50, 50, 50, 50
hidden_dims = [h1, h2, h3, h4]
input_dims = 3*32*32
num_classes = 10
lambda_reg = 0.0
weight_scale = 1e-5

# model
dtype=np.float64

num_layers = 1 + len(hidden_dims)
dtype = dtype
params = {}

dimensions = [input_dims] + hidden_dims + [num_classes]

for i in range(num_layers):
    params['b_%d' % (i + 1)] = np.zeros(dimensions[i + 1])
    params['W_%d' % (i + 1)] = np.random.randn(dimensions[i], dimensions[i + 1]) * weight_scale

for k, v in params.items():
    params[k] = v.astype(dtype)


# set up parameters for training
update_rule='sgd'
learning_rate = 1e-3
batch_size=25
num_epochs=20
print_every=10

# solver

X_train = data['X_train']
y_train = data['y_train']
X_val = data['X_val']
y_val = data['y_val']

# Unpack keyword arguments
update_rule='sgd'
optim_config={'learning_rate': learning_rate,}
lr_decay = 1.0
batch_size = 25
num_epochs = 20
num_train_samples = 1000
num_val_samples = None

checkpoint_name = None
print_every = 10
verbose = True

# Throw an error if there are extra keyword arguments
extra = ', '.join('"%s"' % k for k in list(kwargs.keys()))
raise ValueError('Unrecognized arguments %s' % extra)

# Make sure the update rule exists, then replace the string
# name with the actual function
if not hasattr(optimizer, self.update_rule):
    raise ValueError('Invalid update_rule "%s"' % self.update_rule)
self.update_rule = getattr(optimizer, self.update_rule)

self._reset()


# train
solver.train()

# plot
plt.subplot(2, 1, 1)
plt.title('Training loss')
plt.plot(solver.loss_history, 'o')
plt.xlabel('Iteration')
plt.subplot(2, 1, 2)
plt.title('Accuracy')
plt.plot(solver.train_acc_history, '-o', label='train')
plt.plot(solver.val_acc_history, '-o', label='val')
plt.plot([0.5] * len(solver.val_acc_history), 'k--')
plt.xlabel('Epoch')
plt.legend(loc='lower right')
plt.gcf().set_size_inches(15, 12)
plt.show()
